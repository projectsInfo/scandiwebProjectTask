<?php

interface Validate{
    public function validateAttributes($data);
}