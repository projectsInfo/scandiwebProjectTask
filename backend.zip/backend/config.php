<?php
$db_conn = mysqli_connect("localhost","careemeg_scandiweb","+?VLSH@i1s!q","careemeg_scandiwebTask");